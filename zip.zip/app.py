from flask import Flask, render_template, redirect, url_for, Response, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_apscheduler import APScheduler
from datetime import datetime
import requests

app = Flask(__name__)

api_base = "https://breakernews.net/api/v1/"
api_key = "TsMsvGDMLBbp-kKjSVqRiONSfja5Ocpf"

# ---------------------------------------------------------------------
# SCHEDULED JOB TO FETCH NEWS PERIODICALLY FROM breakernews API
# ---------------------------------------------------------------------
# def fetchNews():
#     # Fetching news from API
#     categoriesInfo = requests.get(api_base + '/news/categories?key=' + api_key).json()
#     categories = categoriesInfo['categories']
#     news = []
#     for category in categories:
#         articles = requests.get(api_base + 'async/news/{0}/20?key={1}'.format(category, api_key))
#         news.append({"category":category, "articles":articles.json()})  
    
#     # Storing news in local database (those news which are not already avaliable)
#     for articles in news:
#         category = articles['category']
#         for article in articles:
#             title = article['title']
#             content = article['body']
#             imageUrl = article['imageUrl']
#             dateCreated = article['date']
            
#             article = Article(title = 'title', content = 'content', date_created = datetime.now, category = 'category')
#             db.session.add(article)
#             db.session.commit()

def joinList(lst, sep=','):
    result = ''
    for index in range(len(lst)-1):
        result += lst[index] + sep

    if len(lst) > 0:
        result += lst[len(lst)-1]
    return result

@app.route('/')
def index():
    return redirect('/en')

@app.route('/<language>/')
def home(language):    
    response = requests.get(api_base + '/news/categories?key=' + api_key + "&lang=" + language)
    if response.status_code == 200:
        categoriesInfo = response.json()
        categories = categoriesInfo['categories']
        joinedCategories = joinList(categories)
        articles = requests.get(api_base + 'news/{0}/6?key={1}&lang={2}'.format(joinedCategories, api_key,language))
        return render_template('index2.html', news = articles.json(), categories = categories, language=language)
    
    return "Website is down"  

@app.route("/<language>/<category>/")
def category(language, category):
    categoriesInfo = requests.get(api_base + '/news/categories?key=' + api_key + "&lang=" + language).json()
    categories = categoriesInfo['categories']    
    articles = requests.get(api_base + 'news/{0}/20?key={1}&lang={2}'.format(category + ",international", api_key, language))
    return render_template('category.html', news = articles.json(), categoryName = category, categories = categories, language=language)

@app.route("/<language>/<category>/<title>")
def details(language, category, title):
    try:
        categoriesInfo = requests.get(api_base + '/news/categories?key=' + api_key + "&lang=" + language).json()
        categories = categoriesInfo['categories']
        title = str(title).replace('-', ' ').lower()
        article = requests.get(api_base + 'news/title/{0}/1?key={1}&lang={2}'.format(title, api_key, language))
        a = article.json()
        articles = requests.get(api_base + 'news/{0}/20?key={1}'.format("international", api_key))
        return render_template('single-post.html', article = a[0], categories = categories, news = articles.json(), language=language, hideBreakingNews=True)
    except Exception as e: 
        return str(e)

@app.route('/test')
def test():
    return jsonify([request.host, request.host_url])



if __name__ == '__main__':
    # scheduler.add_job(id='news fetcher', func = fetchNews, trigger = 'interval', seconds = 20)
    app.run(debug=True, port=1111)